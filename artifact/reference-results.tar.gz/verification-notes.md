# Completed experiment verification

The ten-repetition run completed successfully on 2026-10-13. The outer command
reported `LeanUfo DSL tests passed (full profile with repeated performance experiments)`.
`result.json` reports `valid: true`, ten requested repetitions, and no errors.

Independent recomputation checked all 172 summaries against `raw.jsonl`.
Each summary contains ten measured samples, excluding repetition 0. The raw
file contains 903 records: 31 models, 21 files, and 30 generated inputs in each
of eleven rounds, plus one unsupported-example coverage record. All 25 positive
models certified and all six negative models produced their expected outcomes
in every round. All synthetic counts were stable. All 267 source-content hashes
still matched the files when checked after completion.

The machine was also used for manuscript editing. LaTeX builds and selected-page
rendering overlapped later repetitions, including rounds 7, 8, and 9. No samples
were discarded or adjusted. This was not an isolated-machine performance run.

## Supplementary hardware information

The sandbox denied `sysctl` queries during automatic metadata collection.
The generated `metadata.json` retains its original `unavailable` values.
Separate read-only queries outside that restriction on 2026-10-13 returned:

| Query | Value |
| --- | --- |
| `machdep.cpu.brand_string` | Apple M4 Pro |
| `hw.memsize` | 51539607552 bytes (48 GiB) |
| `hw.physicalcpu` | 14 |
| `hw.logicalcpu` | 14 |
| `hw.perflevel0.physicalcpu` | 10 |
| `hw.perflevel1.physicalcpu` | 4 |

The generated metadata records macOS 26.6.2, Darwin 25.6.0 arm64, and Lean 4.34.0.
